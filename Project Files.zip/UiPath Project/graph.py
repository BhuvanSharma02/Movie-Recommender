import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Read the CSV file into a pandas DataFrame
data = pd.read_csv('Movie.csv')

# Sort the data by title in alphabetical order
data = data.sort_values('Title')

# Find the movie with the highest rating
max_rating = data['Average rating'].max()
highest_rating_movie = data[data['Average rating'] == max_rating]

# Calculate the common genre
common_genre = data['Genres'].str.split(', ').explode().mode().loc[0]  # Get the first mode value

# Calculate the common release year
release_years = data['Year'].unique()
common_release_year = release_years[0] if len(release_years) == 1 else 'Not selected'

# Create the bar graph using plotly
fig = px.bar(data, x=data.index, y='Average rating', color='Title',
             hover_data=['Rank', 'Title', 'Year', 'Genres', 'Total votes'],
             title='Movie Ratings')

# Add marker for the highest rated movie
fig.add_trace(go.Scatter(
    x=[highest_rating_movie.index[0]],
    y=[max_rating + 0.5],
    mode='markers',
    marker=dict(symbol='star', size=12, color='red'),
    showlegend=False
))

# Customize the graph
fig.update_layout(
    xaxis_title='<------Rank----->',
    yaxis_title='<-----Average Rating---->',
    showlegend=False,
    xaxis_tickvals=[],
    title_font=dict(size=24),
    xaxis_title_font=dict(size=20),
    title_y=0.99,
    xaxis=dict(title_standoff=60),
    annotations=[
        dict(
            text="Selected Genre: {}".format(common_genre),
            showarrow=False,
            xref="paper",
            yref="paper",
            x=0.92,
            xanchor="right",
            y=1.08,
            yanchor="top",
            font=dict(size=14),
        ),
        dict(
            text="Release Year: {}".format(common_release_year),
            showarrow=False,
            xref="paper",
            yref="paper",
            x=0.92,
            xanchor="right",
            y=1.1 if common_genre != 'Not selected' else 1.1,  # Adjust the y-coordinate based on genre selection
            yanchor="bottom",
            font=dict(size=14),
        )
    ]
)

# Add movie titles inside the bars
for i, row in data.iterrows():
    title = row['Title']
    if len(title) > 20:  # Adjust the threshold as needed
        title = title[:20] + '...'  # Truncate long titles
    
    bar_height = row['Average rating']
    yshift = -200 if bar_height >= 7 else -150  # Adjust the threshold and yshift value as needed
    
    fig.add_annotation(
        x=i,
        y=row['Average rating'],
        text=title,
        font=dict(size=18),  # Adjust the font size as needed
        showarrow=False,
        textangle=-90,  # Rotate the text vertically
        xanchor='center',  # Center the text horizontally
        yanchor='middle',  # Center the text vertically
        xshift=0,  # No horizontal shift needed
        yshift=yshift,  # Dynamic vertical shift based on bar height
        opacity=0.5
    )

# Display the graph
fig.show()
